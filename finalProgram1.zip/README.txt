WORK IN PROGRESS

Running finalProgram.py currently scrapes data fromm two tables and the item pages within.

Outputs:
data.json: 		data for 10 head items
data2.jason:	data for 10 weapon items


The end goal is to create models that can predict the market value of different types of items based on their stats.