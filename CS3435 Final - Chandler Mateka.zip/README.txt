Running dataCollection.py will produce the the file equipmentData.json, which contains 35 metadata points, both numerical and categorical, for all 3659 equippable items in OldSchool Runescape.

Running dataVisualization will produce the 3 MatPlotLib plots as featured in the powerpoint presentation:
- Scatterplot of strength bonus vs value
- Barplot of avg value by item type
- Volin plot of distribution of value by item type